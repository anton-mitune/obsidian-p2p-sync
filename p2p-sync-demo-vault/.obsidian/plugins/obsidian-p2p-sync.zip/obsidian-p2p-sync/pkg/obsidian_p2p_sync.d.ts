/* tslint:disable */
/* eslint-disable */

export class DeviceKeyPair {
  free(): void;
  [Symbol.dispose](): void;
  get_device_id(): string;
  get_signing_public_key(): string;
  get_key_exchange_public_key(): string;
  constructor(device_id: string);
}

export class DiscoveredPeer {
  free(): void;
  [Symbol.dispose](): void;
  get_device_id(): string;
  get_last_seen_timestamp(): bigint;
  constructor(id: string, name: string, device_id: string, last_seen_timestamp: bigint);
  get_id(): string;
  get_name(): string;
}

export class P2PNode {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Clear all discovered peers
   */
  clear_peers(): void;
  /**
   * Get the peer ID of this node
   */
  get_peer_id(): string;
  /**
   * Remove a discovered peer by ID
   */
  remove_peer(_peer_id: string): void;
  /**
   * Get the device ID
   */
  get_device_id(): string;
  /**
   * Get the number of discovered peers
   */
  get_peer_count(): number;
  /**
   * Stop peer discovery
   */
  stop_discovery(): void;
  /**
   * Get the device name
   */
  get_device_name(): string;
  /**
   * Start peer discovery
   */
  start_discovery(): void;
  /**
   * Add a discovered peer
   */
  add_discovered_peer(_peer: DiscoveredPeer): void;
  /**
   * Get list of discovered peers as JSON
   */
  get_discovered_peers_json(): string;
  /**
   * Create a new P2P node with device configuration
   */
  constructor(device_name: string);
  /**
   * Node status
   */
  status(): string;
}

export class PairingCode {
  free(): void;
  [Symbol.dispose](): void;
  get_qr_data(): string;
  get_fingerprint(): string;
  constructor(code: string, fingerprint: string, created_at: bigint, expires_at: bigint);
  get_code(): string;
  is_valid(current_time: bigint): boolean;
}

export class PairingRequest {
  free(): void;
  [Symbol.dispose](): void;
  get_request_id(): string;
  get_initiator_name(): string;
  get_initiator_device_id(): string;
  constructor(request_id: string, initiator_device_id: string, initiator_name: string, initiator_public_key: string, pairing_code: string, created_at: bigint);
  reject(): void;
  approve(): void;
  get_state(): string;
}

export class SessionKey {
  free(): void;
  [Symbol.dispose](): void;
  is_expired(current_time: bigint): boolean;
  get_peer_id(): string;
  get_cipher_key(): string;
  get_created_at(): bigint;
  get_expires_at(): bigint;
  get_session_id(): string;
  constructor(session_id: string, peer_id: string, cipher_key: string, nonce: string, created_at: bigint, expires_at: bigint);
  get_nonce(): string;
}

/**
 * Generate a device fingerprint from public keys
 */
export function generate_fingerprint(device_id: string): string;

/**
 * Generate a pairing code
 */
export function generate_pairing_code(): string;

/**
 * Get version info
 */
export function get_version(): string;

/**
 * Simple greeting function to test WASM integration
 */
export function greet_from_rust(name: string): string;

/**
 * Initialize panic hook for better error messages in browser console
 */
export function init(): void;

/**
 * Verify a pairing code
 */
export function verify_pairing_code(code: string): boolean;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_devicekeypair_free: (a: number, b: number) => void;
  readonly __wbg_pairingcode_free: (a: number, b: number) => void;
  readonly __wbg_pairingrequest_free: (a: number, b: number) => void;
  readonly __wbg_sessionkey_free: (a: number, b: number) => void;
  readonly devicekeypair_get_device_id: (a: number, b: number) => void;
  readonly devicekeypair_get_key_exchange_public_key: (a: number, b: number) => void;
  readonly devicekeypair_get_signing_public_key: (a: number, b: number) => void;
  readonly devicekeypair_new: (a: number, b: number) => number;
  readonly generate_fingerprint: (a: number, b: number, c: number) => void;
  readonly generate_pairing_code: (a: number) => void;
  readonly pairingcode_get_code: (a: number, b: number) => void;
  readonly pairingcode_get_fingerprint: (a: number, b: number) => void;
  readonly pairingcode_get_qr_data: (a: number, b: number) => void;
  readonly pairingcode_is_valid: (a: number, b: bigint) => number;
  readonly pairingcode_new: (a: number, b: number, c: number, d: number, e: bigint, f: bigint) => number;
  readonly pairingrequest_approve: (a: number) => void;
  readonly pairingrequest_get_initiator_device_id: (a: number, b: number) => void;
  readonly pairingrequest_get_initiator_name: (a: number, b: number) => void;
  readonly pairingrequest_get_request_id: (a: number, b: number) => void;
  readonly pairingrequest_get_state: (a: number, b: number) => void;
  readonly pairingrequest_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: bigint) => number;
  readonly pairingrequest_reject: (a: number) => void;
  readonly sessionkey_get_cipher_key: (a: number, b: number) => void;
  readonly sessionkey_get_created_at: (a: number) => bigint;
  readonly sessionkey_get_expires_at: (a: number) => bigint;
  readonly sessionkey_get_nonce: (a: number, b: number) => void;
  readonly sessionkey_get_peer_id: (a: number, b: number) => void;
  readonly sessionkey_get_session_id: (a: number, b: number) => void;
  readonly sessionkey_is_expired: (a: number, b: bigint) => number;
  readonly sessionkey_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: bigint, j: bigint) => number;
  readonly verify_pairing_code: (a: number, b: number) => number;
  readonly __wbg_discoveredpeer_free: (a: number, b: number) => void;
  readonly __wbg_p2pnode_free: (a: number, b: number) => void;
  readonly discoveredpeer_get_device_id: (a: number, b: number) => void;
  readonly discoveredpeer_get_id: (a: number, b: number) => void;
  readonly discoveredpeer_get_last_seen_timestamp: (a: number) => bigint;
  readonly discoveredpeer_get_name: (a: number, b: number) => void;
  readonly discoveredpeer_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: bigint) => number;
  readonly get_version: (a: number) => void;
  readonly greet_from_rust: (a: number, b: number, c: number) => void;
  readonly init: () => void;
  readonly p2pnode_add_discovered_peer: (a: number, b: number, c: number) => void;
  readonly p2pnode_clear_peers: (a: number, b: number) => void;
  readonly p2pnode_get_device_id: (a: number, b: number) => void;
  readonly p2pnode_get_device_name: (a: number, b: number) => void;
  readonly p2pnode_get_discovered_peers_json: (a: number, b: number) => void;
  readonly p2pnode_get_peer_count: (a: number) => number;
  readonly p2pnode_get_peer_id: (a: number, b: number) => void;
  readonly p2pnode_new: (a: number, b: number) => number;
  readonly p2pnode_remove_peer: (a: number, b: number, c: number, d: number) => void;
  readonly p2pnode_start_discovery: (a: number, b: number) => void;
  readonly p2pnode_status: (a: number, b: number) => void;
  readonly p2pnode_stop_discovery: (a: number, b: number) => void;
  readonly __wbindgen_export: (a: number, b: number, c: number) => void;
  readonly __wbindgen_export2: (a: number) => void;
  readonly __wbindgen_export3: (a: number, b: number) => number;
  readonly __wbindgen_export4: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
